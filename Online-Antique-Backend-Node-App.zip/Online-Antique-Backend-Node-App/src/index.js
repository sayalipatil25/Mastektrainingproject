const express = require("express");
const client = require('./db/connection.js');

const usersRoute = require("./routes/users.js");
const orderRoute = require("./routes/orders.js");
const cartRoute = require("./routes/cartitem.js");
const productRoute = require("./routes/product.js");

var cors = require("./utils/cors.js");
const app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.json());


app.use((req, res, next) => {
    cors.insCors(req, res, next);
});

app.use((req, res, next) => {
    console.log("Incoming request middleware");
    console.log(req.body);
    //console.log(req.params);
    next();
});

app.use("/users", usersRoute);
app.use("/orders", orderRoute);
app.use("/cart", cartRoute);
app.use("/product", productRoute);


app.listen(3300, () => {
    console.log("Sever is now listening at port 3300");
})
client.connect();
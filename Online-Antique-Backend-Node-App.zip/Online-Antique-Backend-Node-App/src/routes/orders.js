const client = require('../db/connection.js')
const express = require('express');

const router = express.Router();
router.use(express.json());



router.get('/order1', (req, res) => {
    client.query(`Select * from od`, (err, result) => {
        if (!err) {
            res.send(result.rows);
        }
    });
    client.end;
})


router.get('/order1/:id', (req, res) => {
    client.query(`Select * from od where orderid=${req.params.id}`, (err, result) => {
        if (!err) {
            res.send(result.rows);
        }
    });
    client.end;
})


router.post('/orders', (req, res, next) => {
    const order = req.body;
    let insertQuery = `insert into od(productid, productname, productdescription, price, quantity, total) 
                       values('${order.productid}', '${order.productname}', '${order.productdescription}', '${order.price}', '${order.quantity}', '${order.total}') `

    client.query(insertQuery, (err, result) => {
        if (!err) {
            res.send('Insertion was successful');
            res.send(result.rows);
        } else { console.log(err.message) }
    })
    client.end;
})

router.put('/orders/:id', (req, res) => {
    let order = req.body;
    let updateQuery = `update od
                       set 
                       productid= ${order.productid},
                       productname='${order.productname}',
                       productdescription = '${order.productdescription}',
                       price = '${order.price}',
                       quantity =${order.quantity},
                       total='${order.total}'
                       where orderid = ${req.params.id}`

    client.query(updateQuery, (err, result) => {
        if (!err) {
            res.send('Update was successful')
        } else { console.log(err.message) }
    })
    client.end;
})

router.delete('/orders/:id', (req, res) => {
    let insertQuery = `delete from orders where od= ${req.params.id}`

    client.query(insertQuery, (err, result) => {
        if (!err) {
            res.send('Deletion was successful')
        } else { console.log(err.message) }
    })
    client.end;
})

module.exports = router;
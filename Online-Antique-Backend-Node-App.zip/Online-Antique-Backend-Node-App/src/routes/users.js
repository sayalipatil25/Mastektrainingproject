const client = require('../db/connection.js')
const express = require('express');

const router = express.Router();
router.use(express.json());



router.get('/users1', (req, res) => {
    client.query(`Select * from users`, (err, result) => {
        if (!err) {
            res.send(result.rows);
        }
    });
    client.end;
})


router.get('/users1/:id', (req, res) => {
    client.query(`Select * from users where userid=${req.params.id}`, (err, result) => {
        if (!err) {
            res.send(result.rows);
        }
    });
    client.end;
})


router.post('/users', (req, res, next) => {
    const user = req.body;
    let insertQuery = `insert into users(userid, username, passwd, firstname, lastname, address, contactno, administrator) 
                       values(${user.userid}, '${user.username}', '${user.passwd}', '${user.firstname}', '${user.lastname}', '${user.address}', '${user.contactno}', '${user.administrator}')`

    client.query(insertQuery, (err, result) => {
        if (!err) {
            res.send('Insertion was successful');
            res.send(result.rows);
        } else { console.log(err.message) }
    })
    client.end;
})

router.put('/users/:id', (req, res) => {
    let user = req.body;
    let updateQuery = `update users
                       set 
                       username = '${user.username}',
                       passwd='${user.passwd}',
                       firstname = '${user.firstname}',
                       lastname = '${user.lastname}',
                       address = '${user.address}',
                       contactno= '${user.contactno}',
                       administrator= '${user.administrator}'
                       where userid = ${req.params.id}`

    client.query(updateQuery, (err, result) => {
        if (!err) {
            res.send('Update was successful')
        } else { console.log(err.message) }
    })
    client.end;
})

router.delete('/users/:id', (req, res) => {
    let insertQuery = `delete from users where userid= ${req.params.id}`

    client.query(insertQuery, (err, result) => {
        if (!err) {
            res.send('Deletion was successful')
        } else { console.log(err.message) }
    })
    client.end;
})

module.exports = router;
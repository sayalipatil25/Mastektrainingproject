package com.training.antique.store.demobackendstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBackendStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoBackendStoreApplication.class, args);
	}

}

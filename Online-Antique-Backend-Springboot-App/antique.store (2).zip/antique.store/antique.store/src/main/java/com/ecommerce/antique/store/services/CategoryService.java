package com.ecommerce.antique.store.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.antique.store.entities.Category;
import com.ecommerce.antique.store.repository.CategoryRepository;

@Service
public class CategoryService {

	@Autowired
	CategoryRepository categoryRepository;
	
	// get/ retrieve the order object along with it's shipping order
	public Category getOrderDetailsById(Long categoryid) {
		
		Optional<Category> opt = categoryRepository.findById(categoryid);

		if(opt.isPresent()){
			return opt.get();
		}
		return null;
	}
}

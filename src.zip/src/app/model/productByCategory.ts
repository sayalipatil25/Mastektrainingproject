export interface ProductByCategory{
  productid: number;
  productname: string;
  productdescription: string;
  productimage: string;
  price: number;
  discountpercent: number;
  discountprice: number;
  reviewscore: number;
  stock: number;
  catagoryid: number;
}
